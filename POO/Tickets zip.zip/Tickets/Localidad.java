public class Localidad {
    private String nombre;
    private double precio;
    private int capacidad;
    private int boletosVendidos;

    public Localidad(String nombre, double precio, int capacidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.capacidad = capacidad;
        this.boletosVendidos = 0;
    }

    public int espacioDisponible() {
        return capacidad - boletosVendidos;
    }

    public int venderBoletos(int cantidad) {
        int disponibles = espacioDisponible();
        int aVender = Math.min(cantidad, disponibles);
        boletosVendidos += aVender;
        return aVender;
    }

    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }

    public int getBoletosVendidos() {
        return boletosVendidos;
    }
}
