import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TicketManager manager = new TicketManager();
        Comprador comprador = null;

        int opcion;
        do {
            System.out.println("\n---- Menú ----");
            System.out.println("1. Nuevo comprador");
            System.out.println("2. Nueva solicitud de boletos");
            System.out.println("3. Consultar disponibilidad total");
            System.out.println("4. Consultar disponibilidad individual");
            System.out.println("5. Reporte de caja");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    System.out.print("Cantidad boletos: ");
                    int cantidad = sc.nextInt();
                    System.out.print("Presupuesto máximo: ");
                    double presupuesto = sc.nextDouble();
                    comprador = new Comprador(nombre, email, cantidad, presupuesto);
                    System.out.println("Comprador creado con ticket #" + comprador.getTicketID());
                    break;
                case 2:
                    if (comprador == null) {
                        System.out.println("Primero cree un comprador.");
                    } else {
                        manager.evaluarSolicitud(comprador);
                    }
                    break;
                case 3:
                    manager.consultarDisponibilidadTotal();
                    break;
                case 4:
                    System.out.print("Ingrese el nombre de la localidad (ej. Localidad 1): ");
                    String loc = sc.nextLine();
                    manager.consultarDisponibilidadIndividual(loc);
                    break;
                case 5:
                    manager.reporteCaja();
                    break;
                case 6:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 6);
        sc.close();
    }
}
