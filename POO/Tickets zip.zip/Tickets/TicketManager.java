import java.util.*;

public class TicketManager {
    private List<Localidad> localidades;
    private int totalBoletosVendidos = 0;
    private double totalDineroGenerado = 0;

    public TicketManager() {
        localidades = new ArrayList<>();
        localidades.add(new Localidad("Localidad 1", 100, 20));
        localidades.add(new Localidad("Localidad 5", 500, 20));
        localidades.add(new Localidad("Localidad 10", 1000, 20));
    }

    public void evaluarSolicitud(Comprador comprador) {
        Random rand = new Random();
        int a = rand.nextInt(15000) + 1;
        int b = rand.nextInt(15000) + 1;

        int min = Math.min(a, b);
        int max = Math.max(a, b);

        int ticketID = comprador.getTicketID();
        if (ticketID < min || ticketID > max) {
            System.out.println("El ticket no fue seleccionado para la compra.");
            return;
        }

        Localidad localidad = localidades.get(rand.nextInt(localidades.size()));

        System.out.println("Localidad asignada: " + localidad.getNombre());

        if (localidad.espacioDisponible() == 0) {
            System.out.println("No hay espacio disponible en la localidad.");
            return;
        }

        int cantidadPosible = Math.min(comprador.getCantidadBoletosDeseados(), localidad.espacioDisponible());

        if (localidad.getPrecio() > comprador.getPresupuestoMax()) {
            System.out.println("El precio excede el presupuesto del comprador.");
            return;
        }

        int vendidos = localidad.venderBoletos(cantidadPosible);
        double total = vendidos * localidad.getPrecio();
        totalBoletosVendidos += vendidos;
        totalDineroGenerado += total;

        System.out.println("Se vendieron " + vendidos + " boletos a " + comprador.getNombre() +
                ". Total pagado: $" + total);
    }

    public void consultarDisponibilidadTotal() {
        for (Localidad l : localidades) {
            System.out.println(l.getNombre() + ": " + l.espacioDisponible() + " disponibles, " +
                    l.getBoletosVendidos() + " vendidos.");
        }
    }

    public void consultarDisponibilidadIndividual(String nombre) {
        for (Localidad l : localidades) {
            if (l.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println(l.getNombre() + ": " + l.espacioDisponible() + " disponibles.");
                return;
            }
        }
        System.out.println("Localidad no encontrada.");
    }

    public void reporteCaja() {
        System.out.println("Total boletos vendidos: " + totalBoletosVendidos);
        System.out.println("Total dinero generado: $" + totalDineroGenerado);
    }
}
