import java.util.Random;

public class Comprador {
    private String nombre;
    private String email;
    private int cantidadBoletosDeseados;
    private double presupuestoMax;
    private int ticketID;

    public Comprador(String nombre, String email, int cantidadBoletosDeseados, double presupuestoMax) {
        this.nombre = nombre;
        this.email = email;
        this.cantidadBoletosDeseados = cantidadBoletosDeseados;
        this.presupuestoMax = presupuestoMax;
        generarTicketID();
    }

    public void generarTicketID() {
        Random rand = new Random();
        this.ticketID = rand.nextInt(15000) + 1;
    }

    public int getTicketID() {
        return ticketID;
    }

    public int getCantidadBoletosDeseados() {
        return cantidadBoletosDeseados;
    }

    public double getPresupuestoMax() {
        return presupuestoMax;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }
}
