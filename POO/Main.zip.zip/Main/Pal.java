class Pal {
    private String nombre;
    private Tipo tipo;
    private int ataqueBase;
    private int defensaBase;
    private ArmamentoEspecial armamento;
    private boolean especialActivoSiguiente;

    public Pal(String nombre, Tipo tipo, int ataqueBase, int defensaBase, ArmamentoEspecial armamento) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.ataqueBase = ataqueBase;
        this.defensaBase = defensaBase;
        this.armamento = armamento;
        this.especialActivoSiguiente = false;
    }

    public int calcularModificadorTipo(Tipo tipoRival) {
        if ((tipo == Tipo.FUEGO && tipoRival == Tipo.PLANTA) ||
            (tipo == Tipo.PLANTA && tipoRival == Tipo.AGUA) ||
            (tipo == Tipo.AGUA && tipoRival == Tipo.FUEGO) ||
            (tipo == Tipo.ELECTRICO && tipoRival == Tipo.AGUA)) {
            return 20; // ventaja
        } else if ((tipo == Tipo.PLANTA && tipoRival == Tipo.FUEGO) ||
                   (tipo == Tipo.AGUA && tipoRival == Tipo.PLANTA) ||
                   (tipo == Tipo.FUEGO && tipoRival == Tipo.AGUA)) {
            return -10; // desventaja
        }
        return 0; // neutral
    }

    public int getAtaqueTotal(Pal rival, boolean activarEspecial) {
        int total = ataqueBase + calcularModificadorTipo(rival.tipo);

        if (especialActivoSiguiente) {
            total = armamento.aplicarEfectoAtaque(total);
            especialActivoSiguiente = false;
        }

        if (activarEspecial && armamento.seActiva()) {
            total = armamento.aplicarEfectoAtaque(total);
            especialActivoSiguiente = true;
            System.out.println(nombre + " activó su habilidad especial: " + armamento.getNombre());
        }

        return total;
    }

    public String getNombre() {
        return nombre;
    }

    public Tipo getTipo() {
        return tipo;
    }
}
