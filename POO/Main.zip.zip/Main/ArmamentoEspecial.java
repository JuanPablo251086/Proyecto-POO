class ArmamentoEspecial {
    private String nombre;
    private Efecto tipoEfecto;
    private int valor;
    private double probabilidad;

    public ArmamentoEspecial(String nombre, Efecto tipoEfecto, int valor, double probabilidad) {
        this.nombre = nombre;
        this.tipoEfecto = tipoEfecto;
        this.valor = valor;
        this.probabilidad = probabilidad;
    }

    // mira si la habilidad especial se activa en esta ronda
    public boolean seActiva() {
        return Math.random() <= probabilidad;
    }

    public int aplicarEfectoAtaque(int ataqueOriginal) {
        if (tipoEfecto == Efecto.AUMENTAR_ATAQUE || tipoEfecto == Efecto.DANIO_DIRECTO) {
            return ataqueOriginal + valor;
        }
        return ataqueOriginal;
    }

    public int aplicarEfectoDefensa(int defensaOriginal) {
        if (tipoEfecto == Efecto.AUMENTAR_DEFENSA) {
            return defensaOriginal + valor;
        }
        return defensaOriginal;
    }

    public String getNombre() {
        return nombre;
    }

    public Efecto getTipoEfecto() {
        return tipoEfecto;
    }

    public int getValor() {
        return valor;
    }
}
