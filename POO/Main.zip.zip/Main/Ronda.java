class Ronda {
    private Pal pal1;
    private Pal pal2;
    private boolean activar1;
    private boolean activar2;

    public Ronda(Pal pal1, boolean activar1, Pal pal2, boolean activar2) {
        this.pal1 = pal1;
        this.pal2 = pal2;
        this.activar1 = activar1;
        this.activar2 = activar2;
    }

    public int jugar() {
        int ataque1 = pal1.getAtaqueTotal(pal2, activar1);
        int ataque2 = pal2.getAtaqueTotal(pal1, activar2);

        System.out.println(pal1.getNombre() + " ataca con " + ataque1);
        System.out.println(pal2.getNombre() + " ataca con " + ataque2);

        if (ataque1 > ataque2) return 1;
        if (ataque2 > ataque1) return 2;
        return 0;
    }
}
