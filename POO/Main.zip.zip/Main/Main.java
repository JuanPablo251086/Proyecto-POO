public class Main {
    public static void main(String[] args) {

        ArmamentoEspecial fuego = new ArmamentoEspecial("Llama Solar", Efecto.AUMENTAR_ATAQUE, 15, 0.5);
        ArmamentoEspecial agua = new ArmamentoEspecial("Ola Curativa", Efecto.AUMENTAR_DEFENSA, 10, 0.3);
        ArmamentoEspecial planta = new ArmamentoEspecial("Raíces Venenosas", Efecto.DANIO_DIRECTO, 20, 0.4);

        Pal[] palsAsh = {
            new Pal("Flamo", Tipo.FUEGO, 50, 30, fuego),
            new Pal("Aqual", Tipo.AGUA, 40, 35, agua),
            new Pal("Leafy", Tipo.PLANTA, 45, 25, planta)
        };

        Pal[] palsMisty = {
            new Pal("Volt", Tipo.ELECTRICO, 48, 28, fuego),
            new Pal("Splash", Tipo.AGUA, 42, 32, agua),
            new Pal("Bud", Tipo.PLANTA, 43, 27, planta)
        };

        Entrenador ash = new Entrenador("Ash", palsAsh);
        Entrenador misty = new Entrenador("Misty", palsMisty);

        for (int ronda = 0; ronda < 3; ronda++) {
            System.out.println("\n--- RONDA " + (ronda + 1) + " ---");

            Pal p1 = ash.getPal(ronda);
            Pal p2 = misty.getPal(ronda);

            boolean activar1 = Math.random() < 0.5;
            boolean activar2 = Math.random() < 0.5;

            Ronda r = new Ronda(p1, activar1, p2, activar2);
            int resultado = r.jugar();

            if (resultado == 1) {
                ash.ganarRonda();
                System.out.println("Ash gana la ronda.");
            } else if (resultado == 2) {
                misty.ganarRonda();
                System.out.println("Misty gana la ronda.");
            } else {
                System.out.println("Empate.");
            }
        }

        System.out.println("\n--- RESULTADO FINAL ---");
        System.out.println("Ash ganó " + ash.getRondasGanadas() + " ronda(s).");
        System.out.println("Misty ganó " + misty.getRondasGanadas() + " ronda(s).");

        if (ash.getRondasGanadas() > misty.getRondasGanadas()) {
            System.out.println("Ganador final: Ash");
        } else if (misty.getRondasGanadas() > ash.getRondasGanadas()) {
            System.out.println("Ganador final: Misty");
        } else {
            System.out.println("El combate terminó en empate.");
        }
    }
}
