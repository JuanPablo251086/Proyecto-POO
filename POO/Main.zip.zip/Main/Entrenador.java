class Entrenador {
    private String nombre;
    private Pal[] pals;
    private int rondasGanadas;

    public Entrenador(String nombre, Pal[] pals) {
        this.nombre = nombre;
        this.pals = pals;
        this.rondasGanadas = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public Pal getPal(int ronda) {
        return pals[ronda];
    }

    public void ganarRonda() {
        rondasGanadas++;
    }

    public int getRondasGanadas() {
        return rondasGanadas;
    }
}
