enum Tipo {
    FUEGO,
    AGUA,
    PLANTA,
    ELECTRICO
}
