import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("pone el nombre del jugador 1 (X): ");
        String nombre1 = sc.nextLine();
        Jugador j1 = new Jugador(nombre1, "X");

        System.out.print("pone el nombre del jugador 2 (O): ");
        String nombre2 = sc.nextLine();
        Jugador j2 = new Jugador(nombre2, "O");

        Juego juego = new Juego(j1, j2);

        int opcion = 1;
        while (opcion != 0) {
            juego.reiniciarPartida();
            String ganador = null;

            while (ganador == null) {
                System.out.println(juego.getTablero().mostrarTablero());
                System.out.println("Le toca a " + juego.getTurnoActual().getNombre() +
                                   " (" + juego.getTurnoActual().getMarca() + ")");
                System.out.print("Fila (0-2): ");
                int fila = sc.nextInt();
                System.out.print("Columna (0-2): ");
                int col = sc.nextInt();

                if (juego.jugarMovimiento(fila, col)) {
                    ganador = juego.verificarFinPartida();
                    if (ganador == null) {
                        juego.cambiarTurno();
                    }
                } else {
                    System.out.println("esto no se puede, intenta otro movimiento.");
                }
            }

            System.out.println(juego.getTablero().mostrarTablero());
            if (ganador.equals("Empate")) {
                System.out.println("La partida terminó en empate.");
            } else {
                System.out.println("Ganador: " + ganador);
            }

            System.out.println("\n¿Quieren jugar otra vez? (1 = Sí, 0 = No): ");
            opcion = sc.nextInt();
        }

        System.out.println(juego.generarReporteFinal());
        sc.close();
    }
}
