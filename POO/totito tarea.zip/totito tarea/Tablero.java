public class Tablero {
    private String[][] grid;

    public Tablero() {
        grid = new String[3][3];
        inicializar();
    }

    public void inicializar() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                grid[i][j] = " ";
            }
        }
    }

    public boolean colocarMarca(int fila, int columna, String marca) {
        if (fila >= 0 && fila < 3 && columna >= 0 && columna < 3) {
            if (grid[fila][columna].equals(" ")) {
                grid[fila][columna] = marca;
                return true;
            }
        }
        return false;
    }

    public boolean estaLleno() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (grid[i][j].equals(" ")) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean hayGanador(String marca) {
        
        for (int i = 0; i < 3; i++) {
            if (grid[i][0].equals(marca) && grid[i][1].equals(marca) && grid[i][2].equals(marca)) {
                return true;
            }
            if (grid[0][i].equals(marca) && grid[1][i].equals(marca) && grid[2][i].equals(marca)) {
                return true;
            }
        }
    
        if (grid[0][0].equals(marca) && grid[1][1].equals(marca) && grid[2][2].equals(marca)) {
            return true;
        }
        if (grid[0][2].equals(marca) && grid[1][1].equals(marca) && grid[2][0].equals(marca)) {
            return true;
        }
        return false;
    }

    public String mostrarTablero() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            sb.append(" ");
            for (int j = 0; j < 3; j++) {
                sb.append(grid[i][j]);
                if (j < 2) sb.append(" | ");
            }
            sb.append("\n");
            if (i < 2) sb.append("-----------\n");
        }
        return sb.toString();
    }
}
