public class Jugador {
    private String nombre;
    private String marca; 
    private int partidasGanadas;

    public Jugador(String nombre, String marca) {
        this.nombre = nombre;
        this.marca = marca;
        this.partidasGanadas = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public String getMarca() {
        return marca;
    }

    public int getVictorias() {
        return partidasGanadas;
    }

    public void incrementarVictorias() {
        partidasGanadas++;
    }
}
