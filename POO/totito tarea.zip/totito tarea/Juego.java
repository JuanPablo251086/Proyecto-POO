public class Juego {
    private Jugador jugador1;
    private Jugador jugador2;
    private Tablero tablero;
    private Jugador turnoActual;
    private int partidasJugadas;

    public Juego(Jugador j1, Jugador j2) {
        this.jugador1 = j1;
        this.jugador2 = j2;
        this.tablero = new Tablero();
        this.turnoActual = j1; 
        this.partidasJugadas = 0;
    }

    public Tablero getTablero() {
        return tablero;
    }

    public Jugador getTurnoActual() {
        return turnoActual;
    }

    public void cambiarTurno() {
        if (turnoActual == jugador1) {
            turnoActual = jugador2;
        } else {
            turnoActual = jugador1;
        }
    }

    public boolean jugarMovimiento(int fila, int columna) {
        return tablero.colocarMarca(fila, columna, turnoActual.getMarca());
    }

    public String verificarFinPartida() {
        if (tablero.hayGanador(jugador1.getMarca())) {
            jugador1.incrementarVictorias();
            partidasJugadas++;
            return jugador1.getNombre();
        }
        if (tablero.hayGanador(jugador2.getMarca())) {
            jugador2.incrementarVictorias();
            partidasJugadas++;
            return jugador2.getNombre();
        }
        if (tablero.estaLleno()) {
            partidasJugadas++;
            return "Empate";
        }
        return null; 
    }

    public void reiniciarPartida() {
        tablero.inicializar();
        turnoActual = jugador1; 
    }

    public String generarReporteFinal() {
        StringBuilder sb = new StringBuilder("=== REPORTE FINAL ===\n");
        sb.append(jugador1.getNombre()).append(" (").append(jugador1.getMarca())
          .append(") ganó: ").append(jugador1.getVictorias()).append(" partidas\n");
        sb.append(jugador2.getNombre()).append(" (").append(jugador2.getMarca())
          .append(") ganó: ").append(jugador2.getVictorias()).append(" partidas\n");

        if (jugador1.getVictorias() > jugador2.getVictorias()) {
            sb.append("Ganador global: ").append(jugador1.getNombre());
        } else if (jugador2.getVictorias() > jugador1.getVictorias()) {
            sb.append("Ganador global: ").append(jugador2.getNombre());
        } else {
            sb.append("La sesión terminó en empate");
        }
        return sb.toString();
    }
}
